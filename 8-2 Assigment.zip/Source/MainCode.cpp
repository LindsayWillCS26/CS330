#include <GLFW\glfw3.h>
#include "linmath.h"
#include <stdlib.h>
#include <stdio.h>
#include <conio.h>
#include <iostream>
#include <vector>
#include <windows.h>
#include <time.h>
#include <cmath>

using namespace std;

const float DEG2RAD = 3.14159f / 180.0f;

void processInput(GLFWwindow* window);

enum BRICKTYPE { REFLECTIVE, DESTRUCTABLE };
enum ONOFF { ON, OFF };

class Brick
{
public:
	float red, green, blue;
	float x, y, width;
	BRICKTYPE brick_type;
	ONOFF onoff;
	int hit_count; // Multi hit feature

	Brick(BRICKTYPE bt, float xx, float yy, float ww, float rr, float gg, float bb)
	{
		brick_type = bt; 
		x = xx; 
		y = yy; 
		width = ww;
		red = rr;
		green = gg;
		blue = bb;
		onoff = ON;
		hit_count = (bt == DESTRUCTABLE) ? 2 : 0;// Requires 2 hits to break
	}

	void drawBrick()
	{
		if (onoff == ON)
		{
			double halfside = width / 2.0;

			glColor3d(red, green, blue);
			glBegin(GL_POLYGON);

			glVertex2d(x + halfside, y + halfside);
			glVertex2d(x + halfside, y - halfside);
			glVertex2d(x - halfside, y - halfside);
			glVertex2d(x - halfside, y + halfside);

			glEnd();
		}
	};
};


class Circle
{
public:
	float red, green, blue;
	float radius;
	float x;
	float y;
	float speed = 0.03;
	int direction; // 1=up 2=right 3=down 4=left 5 = up right   6 = up left  7 = down right  8= down left
	bool active = true;

	//Parameter ordering matches original setup: (x, y, dir, rad, r, g, b)
	Circle(double xx, double yy, int dir, float rad, float r, float g, float b)
	{
		x = (float)xx;
		y = (float)yy;
		direction = dir;
		radius = rad;
		red = r;
		green = g;
		blue = b;
	}

	int GetRandomDirection()
	{
		return (rand() % 8) + 1;
	}

	void CheckCollision(Brick* brk)
	{
		if (brk->onoff == OFF) return;

		double halfside = brk->width / 2;

		// Bounding box collision accounting for circle radius
		bool hitX = (x + radius >= brk->x - halfside) && (x - radius <= brk->x + halfside);
		bool hitY = (y + radius >= brk->y - halfside) && (y - radius <= brk->y + halfside);

		if (hitX && hitY)
		{
			if (brk->brick_type == REFLECTIVE)
			{
				direction = GetRandomDirection();
			}
			else if (brk->brick_type == DESTRUCTABLE)
			{
				brk->hit_count--;

				//Change color to indicate damage
				brk->red *= 0.5f;
				brk->green *= 0.5f;
				brk->blue *= 0.5f;

				if (brk->hit_count <= 0)
				{
					brk->onoff = OFF;
				}
				direction = GetRandomDirection();
			}
		}
	}

	void MoveOneStep()
	{
		if (!active) return;


		//Vertidcal movement updates
		if (direction == 1 || direction == 5 || direction == 6)  // up
			y += speed;
		else if (direction == 3 || direction == 7 || direction == 8)
				y -= speed;

		//Horizontal movement updates
		if (direction == 2 || direction == 5 || direction == 7)  // right
			x += speed;
		else if (direction == 4 || direction == 6 || direction == 8)
			x -= speed;

		//Screen boundary bouncing (-1.0 to 1.0 cordinate space)
		if (x >= 1.0f - radius || x <= -1.0f + radius ||
			y >= 1.0f - radius || y <= -1.0f + radius)
		{
			direction = GetRandomDirection();
		}
	}

	void DrawCircle()
	{
		if (!active) return;

		glColor3f(red, green, blue);
		glBegin(GL_POLYGON);
		for (int i = 0; i < 360; i += 10) {
			float rad = i * DEG2RAD;
			glVertex2f((cos(rad) * radius) + x, (sin(rad) * radius));
		}
		glEnd();
	}
};


vector<Circle> world;

//Handles circle to circle interactions.
void CheckCircleCollisions()
{
	for (size_t i = 0; i < world.size(); ++i)
	{ 
		for (size_t j = i + 1; j < world.size(); ++j)
		{
			if (world[i].active && world[j].active)
			{
				float dx = world[i].x - world[j].x;
				float dy = world[i].y - world[j].y;
				float distSq = (dx * dx) + (dy * dy);
				float combinedRadius = world[i].radius + world[j].radius;
				
				if (distSq <= combinedRadius * combinedRadius)
				{
					//Combine into single larger gold circle
					world[i].radius += 0.015f;
					world[i].red = 1.0f; // Change color to gold
					world[i].green = 0.84f;
					world[i].blue = 0.0f;
					world[i].direction = world[i].GetRandomDirection();

					//Deactivate the second circl
					world[j].active = false;
				}
			}
		}
	}
}

int main(void) 
{
	srand((unsigned)time(NULL));

	if (!glfwInit()) {
		exit(EXIT_FAILURE);
	}
	glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 2);
	glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 0);

	GLFWwindow* window = glfwCreateWindow(480, 480, "8-2 Assignment", NULL, NULL);
	if (!window) 
	{
		glfwTerminate();
		exit(EXIT_FAILURE);
	}

	glfwMakeContextCurrent(window);
	glfwSwapInterval(1);

	//Grid layout of bricks
	Brick brick(REFLECTIVE, 0.5f, -0.33f, 0.2f, 1.0f, 1.0f, 0.0f);
	Brick brick2(DESTRUCTABLE, -0.5f, 0.33f, 0.2f, 0.0f, 1.0f, 0.0f);
	Brick brick3(DESTRUCTABLE, -0.5f, -0.33f, 0.2f, 0.0f, 1.0f, 1.0f);
	Brick brick4(REFLECTIVE, 0.0f, 0.0f, 0.2f, 1.0f, 0.5f, 0.5f);

	Circle startingCircle(0.0, 0.0, 5, 0.06f, 1.0f, 1.0f, 1.0f);
	world.push_back(startingCircle);

	while (!glfwWindowShouldClose(window)) 
	{
		int width, height;

		glfwGetFramebufferSize(window, &width, &height);
		glViewport(0, 0, width, height);
		glClear(GL_COLOR_BUFFER_BIT);

		processInput(window);

		//Movement and Brick collision
		for (int i = 0; i < world.size(); i++)
		{
			world[i].CheckCollision(&brick);
			world[i].CheckCollision(&brick2);
			world[i].CheckCollision(&brick3);
			world[i].CheckCollision(&brick4);
			world[i].MoveOneStep();
			world[i].DrawCircle();

		}
		//Check interactions between circles
		CheckCircleCollisions();

		//Render Bricks
		brick.drawBrick();
		brick2.drawBrick();
		brick3.drawBrick();
		brick4.drawBrick();

		glfwSwapBuffers(window);
		glfwPollEvents();
	}

	glfwDestroyWindow(window);
	glfwTerminate;
	exit(EXIT_SUCCESS);
}


void processInput(GLFWwindow* window)
{
	if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
		glfwSetWindowShouldClose(window, true);

	if (glfwGetKey(window, GLFW_KEY_SPACE) == GLFW_PRESS)
	{
		float r = (float)(rand() % 100) / 100.0f;
		float g = (float)(rand() % 100) / 100.0f;
		float b = (float)(rand() % 100) / 100.0f;
		int randomDir = (rand() % 8) + 1;

		//Corrected instantiation and random color generation to match 7-parameter: (x, y, dir, rad, r, g, b)
		Circle c(0.0, 0.0, randomDir, 0.5f, r, g, b);
		world.push_back(c);

		//Brief sleep to avoid rapid spam on single key press
		Sleep(150);
	}
}